# 数据拉取计划

## 目标
1. 为PURIF项目拉取核心思想验证所需的数据
2. 为重点关注的A股公司拉取金融数据并保存到本地

## Stage 1 — 数据源技能加载
- 读取 yahoo_finance SKILL.md 和 get_datasource_desc
- 读取 ifind SKILL.md 和 get_datasource_desc
- 了解可用的API和数据格式

## Stage 2 — PURIF项目数据需求分析
- 根据PURIF项目（异常检测、子图优化、个性化PageRank传播）确定需要的数据类型
- 可能需要：图数据、网络结构数据、异常标注数据等

## Stage 3 — Watchlist公司数据拉取
- 将公司名称转换为对应股票代码（A股）
- 使用ifind拉取基本面数据（财务指标、估值、分红等）
- 使用yahoo_finance补充行情数据
- 适配导入格式，保存到 F:\invest_wiki\invest_wiki\watchlist-data

## Stage 4 — 数据验证与汇总
- 检查数据完整性和格式
- 输出汇总报告
