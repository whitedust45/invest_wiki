# 红利低波策略 - 数据文件索引

> 策略核心：高股息 + 低估值 + 低波动  
> 覆盖标的：16只A股 + 3只红利低波ETF  
> 数据时间：2024-06-28 至 2026-06-28（2年日线）  
> 生成时间：2026-06-28

---

## 一、核心策略指标总览表

**文件**: `00_红利低波策略指标总览.csv`  
包含全部19只标的的估值+股息+波动率核心指标，可直接用于策略筛选：

| 指标类别 | 字段 | 说明 |
|----------|------|------|
| 估值 | PE_TTM, 前瞻PE, PB, PS, EV_EBITDA | 市盈率/市净率/市销率/EV_EBITDA |
| 股息 | 每股股息, 股息率_%, 五年均息率_%, 派息率_% | 当前及历史股息水平 |
| 波动 | 年波动率_%, Beta, 最大回撤_% | 250日年化波动率 |
| 质量 | ROE_%, 净利率_%, 毛利率_% | 盈利质量 |
| 成长 | 营收增长_%, 盈利增长_% | 成长性 |
| 风险 | 夏普比率, 负债权益比 | 风险调整后收益 |

---

## 二、波动率详细指标

**文件**: `00_volatility_metrics.csv`  
包含多时间维度波动率，用于低波筛选：

| 字段 | 说明 |
|------|------|
| latest_vol_20d | 20日波动率（月频） |
| latest_vol_60d | 60日波动率（季频） |
| latest_vol_120d | 120日波动率（半年频） |
| latest_vol_250d | 250日波动率（年频） |
| max_drawdown | 最大回撤 |
| sharpe_ratio | 夏普比率 |
| sortino_ratio | 索提诺比率 |
| calmar_ratio | 卡玛比率 |

---

## 三、个股数据文件（16只A股）

### 文件命名规则
- `{ticker}_{exchange}_yahoo_info.csv` — Yahoo综合信息（估值、股息、财务指标）
- `{ticker}_{exchange}_yahoo_price_2y.csv` — 2年日线行情（Open/High/Low/Close/Volume）
- `{ticker}_{exchange}_yahoo_actions.csv` — 分红拆股记录
- `{ticker}_{exchange}_yahoo_recommendations.csv` — 分析师推荐
- `batch{n}_*.csv` — iFinD财务数据（按批次分组）

### 16只关注股票

| 名称 | 代码 | 简称 | Yahoo代码 |
|------|------|------|-----------|
| 五粮液 | 000858.SZ | Wuliangye | 000858_SZ |
| 泸州老窖 | 000568.SZ | Luzhou Laojiao | 000568_SZ |
| 伊利股份 | 600887.SH | Yili | 600887_SS |
| 建发股份 | 600153.SH | C&D Inc. | 600153_SS |
| 招商银行 | 600036.SH | CMB | 600036_SS |
| 富森美 | 002818.SZ | Fusenmei | 002818_SZ |
| 江苏国泰 | 002091.SZ | Guotai | 002091_SZ |
| 中国建筑 | 601668.SH | CSCEC | 601668_SS |
| 雅戈尔 | 600177.SH | Youngor | 600177_SS |
| 梅花生物 | 600873.SH | Meihua | 600873_SS |
| 中国平安 | 601318.SH | Ping An | 601318_SS |
| 中国海油 | 600938.SH | CNOOC | 600938_SS |
| 中国移动 | 600941.SH | China Mobile | 600941_SS |
| 陕西煤业 | 601225.SH | Shaanxi Coal | 601225_SS |
| 格力电器 | 000651.SZ | Gree | 000651_SZ |
| 海尔智家 | 600690.SH | Haier | 600690_SS |

### iFinD Batch 分组（6批，每批最多3只）

| Batch | 股票 | 数据类型 |
|-------|------|----------|
| batch1 | 五粮液、泸州老窖、伊利股份 | 成长/偿债/流动性/财务报表/业务分部/股东/盈利 |
| batch2 | 建发股份、招商银行、富森美 | 成长/效率/现金流覆盖/财务报表/股东/价格 |
| batch3 | 江苏国泰、中国建筑、雅戈尔 | 成长/现金流覆盖/业务分部/预测 |
| batch4 | 梅花生物、中国平安、中国海油 | 成长/偿债/财务报表/股东/预测/价格 |
| batch5 | 中国移动、陕西煤业、格力电器 | 流动性/现金流覆盖/财务报表/预测/价格 |
| batch6 | 海尔智家 | **全部12项（最完整）** |

---

## 四、ETF 数据文件（3只）

| 名称 | 代码 | 文件前缀 | Yahoo数据 |
|------|------|----------|-----------|
| 红利低波ETF | 512890.SH | hldj | hldj_etf_yahoo_*.csv |
| 港股通红利低波 | 159569.SZ | ggt_hldj | ggt_hldj_etf_yahoo_*.csv |
| 恒生红利低波 | 520890.SH | hs_hldj | hs_hldj_etf_yahoo_*.csv |

ETF的Yahoo info字段与股票不同，估值/股息指标需通过成分股推算或参考iFinD数据。

---

## 五、Python 导入示例

```python
import pandas as pd
import os

BASE = r"F:\invest_wiki\invest_wiki\watchlist-data"

# 1. 读取策略核心指标总览（推荐首选）
df = pd.read_csv(os.path.join(BASE, "00_红利低波策略指标总览.csv"), encoding='utf-8-sig')

# 按股息率排序
high_dividend = df.nlargest(5, '股息率_%')[['名称', '股息率_%', 'PE_TTM', 'PB', '年波动率_%']]

# 低波筛选: 波动率<20%且股息率>5%
low_vol_high_div = df[(df['年波动率_%'] < 20) & (df['股息率_%'] > 5)]

# 2. 读取某只股票的历史行情
df_price = pd.read_csv(os.path.join(BASE, "000858_SZ_yahoo_price_2y.csv"))
df_price['Date'] = pd.to_datetime(df_price['Date'])
df_price = df_price.sort_values('Date')

# 计算自定义波动率
df_price['returns'] = df_price['Close'].pct_change()
vol_20d = df_price['returns'].rolling(20).std() * (252 ** 0.5)

# 3. 读取分红记录
df_div = pd.read_csv(os.path.join(BASE, "000858_SZ_yahoo_actions.csv"))
dividends = df_div[df_div['Dividends'] > 0]  # 仅看分红

# 4. 批量计算所有股票的滚动波动率
import glob
for f in glob.glob(os.path.join(BASE, "*_yahoo_price_2y.csv")):
    df_p = pd.read_csv(f)
    # ... 自定义计算
```

---

## 六、红利低波策略数据字段速查

### 估值指标（来自 *_yahoo_info.csv）
| 字段 | 说明 | 策略用途 |
|------|------|----------|
| trailingPE | 市盈率TTM | 低估值筛选 |
| forwardPE | 前瞻市盈率 | 未来估值判断 |
| priceToBook | 市净率 | 低PB筛选 |
| priceToSalesTrailing12Months | 市销率 | 辅助估值 |
| enterpriseToEbitda | EV/EBITDA | 企业价值评估 |

### 股息指标（来自 *_yahoo_info.csv + *_yahoo_actions.csv）
| 字段 | 说明 | 策略用途 |
|------|------|----------|
| dividendRate | 每股年度股息 | 绝对股息水平 |
| dividendYield | 股息率(%) | **核心筛选指标** |
| fiveYearAvgDividendYield | 5年平均股息率(%) | 股息稳定性 |
| payoutRatio | 派息率 | 股息可持续性 |
| Dividends (actions) | 历史每股分红 | 分红连续性 |

### 波动率指标（已预计算在 00_volatility_metrics.csv）
| 字段 | 说明 | 策略用途 |
|------|------|----------|
| latest_vol_250d | 250日年化波动率 | **核心低波指标** |
| beta | Beta系数 | 系统性风险 |
| max_drawdown | 最大回撤 | 下行风险 |
| sharpe_ratio | 夏普比率 | 风险调整后收益 |
